export const environment = {
  production: true,
  baseUrl: 'https://api.openweathermap.org/data/2.5/forecast',
  appId: '78c6b64f54db08d8254473fd536c3bf6',
  cityId: '1277333'
};
